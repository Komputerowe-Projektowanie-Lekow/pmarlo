For the more general information use the AGENTS.md in the src/pmarlo.

# Analysis module
This is the analysis module. It should be responsible the {analysis explanation}
