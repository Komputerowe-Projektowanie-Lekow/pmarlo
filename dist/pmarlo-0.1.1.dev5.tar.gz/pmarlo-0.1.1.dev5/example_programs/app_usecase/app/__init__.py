"""PMARLO Sharded MSM App package for local demos.

This folder is intentionally kept lightweight and self-contained.
"""
