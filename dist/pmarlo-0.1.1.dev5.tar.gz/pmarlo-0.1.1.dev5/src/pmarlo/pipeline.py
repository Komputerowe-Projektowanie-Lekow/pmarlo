"""Compatibility wrapper re-exporting :mod:`pmarlo.transform.pipeline`."""

from __future__ import annotations

from pmarlo.transform.pipeline import *  # noqa: F401,F403
