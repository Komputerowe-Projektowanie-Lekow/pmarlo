Currently those scripts are only for the codex environment preparation. Those shouldn't be used in the normal workflows and any preparation workflow for the environment.
