"""Unit tests for feature engineering components."""
