"""Unit tests for collective variable components."""
