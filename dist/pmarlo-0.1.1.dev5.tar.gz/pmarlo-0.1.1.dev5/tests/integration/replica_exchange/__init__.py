import pytest

pytest.importorskip("openmm")
pytest.importorskip("mdtraj")
