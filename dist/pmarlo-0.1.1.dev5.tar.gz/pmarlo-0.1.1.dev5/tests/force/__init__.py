# Helpers for force validation tests
