For the more general information use the AGENTS.md in the src/pmarlo.

# Data module
This is the Data module. It should be responsible the {analysis explanation}
